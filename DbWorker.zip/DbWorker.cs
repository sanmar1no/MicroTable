﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Microsoft.Data.Sqlite;
using System.Data.SQLite;
using System.Data;
using Dapper;


namespace MicroTable
{
    class DbWorker
    {
        private static string dataSource = "./MyMicroTableDB.db";
        public DbWorker()
        {
        }

        private int FindLastID()
        {
            int ID = -1;
            SQLiteConnection.CreateFile(dataSource);
            using (IDbConnection db = new SQLiteConnection($"Data Source={dataSource};Version=3;"))
            {
                var id = db.Query<long>(@"INSERT INTO Client ( Name ) VALUES ('Anton');
                             select last_insert_rowid();
                ").First();
            }
            return ID;
        }


        private SqliteConnection getConnection()
        {
            SqliteConnectionStringBuilder scs = new SqliteConnectionStringBuilder();
            scs.DataSource = dataSource;

            return new SqliteConnection(scs.ConnectionString);
        }

        //Метод создаёт таблицу rooms в БД, если её ещё не было
        public void createRoomsTable()
        {
            string s = "CREATE TABLE IF NOT EXISTS rooms (" +
                                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                "building TEXT NOT NULL," +                             
                                "room TEXT NOT NULL," +
                                "clientID TEXT NOT NULL"+
                                ");";

            ExecuteQuery(s);
        }

        //Метод создаёт таблицу counters в БД, если её ещё не было
        public void createCountersTable()
        {
            string s = "CREATE TABLE IF NOT EXISTS counters (" +
                                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                "number TEXT NOT NULL," +
                                "ratio REAL NOT NULL," +
                                "roomID INTEGER NOT NULL" +                                
                                ");";

            ExecuteQuery(s);
        }

        //Метод создаёт таблицу records в БД, если её ещё не было
        public void createRecordsTable()
        {
            string s = "CREATE TABLE IF NOT EXISTS records (" +
                                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                "date DATETIME NOT NULL," +
                                "value REAL NOT NULL," +
                                "counterID INTEGER NOT NULL" +
                                ");";

            ExecuteQuery(s);
        }

        //Метод создаёт таблицу clients в БД, если её ещё не было
        public void createClientsTable()
        {
            string s = "CREATE TABLE IF NOT EXISTS clients (" +
                                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                "name TEXT NOT NULL UNIQUE" +
                                ");";

            ExecuteQuery(s);
        }

        //метод выполняет запрос к БД SQLite
        private void ExecuteQuery(string Query)
        {
            using (SqliteConnection connection = getConnection())
            {
                connection.Open();
                SqliteCommand cmd = connection.CreateCommand();
                cmd.CommandText = Query;
                cmd.ExecuteNonQuery();
            }
        }
        //Метод вставляет данные в таблицу clients из одного объекта Client
        public void insertClientsTable(Client c)
        {

            string s = "INSERT INTO clients (" +
                "name) VALUES" +
                $"('{c.name}');";

            ExecuteQuery(s);
            int ID = selectCurrentID();// "clients");
            foreach (Room r in c.roomsClient)
                insertRoomsTable(r,ID);
            //вставить счетчики
        }

        //Метод вставляет данные в таблицу rooms из одного объекта Room
        public void insertRoomsTable(Room r, int clientID)
        {

            string s = "INSERT INTO rooms (" +
                "building, room, clientID) VALUES" +
                $"('{r.building}', '{r.room}','{clientID}');";

            ExecuteQuery(s);
            int ID = selectCurrentID();// "rooms");
            foreach (Counter c in r.counters)
                insertCountersTable(c,ID);
            //вставить счетчики
        }

        //Метод вставляет данные в таблицу counters из одного объекта Counter
        public void insertCountersTable(Counter c, int roomID)
        {

            string s = "INSERT INTO counters (" +
                "number, ratio, roomID) VALUES" +
                $"('{c.number}', '{c.ratio}','{roomID}');";

            ExecuteQuery(s);
            int ID = selectCurrentID();//"counters");
            foreach (Record r in c.records)
                insertRecordsTable(r,ID);
        }

        //Метод вставляет данные в таблицу records из одного объекта Record
        public void insertRecordsTable(Record r, int counterID)
        {

            string s = "INSERT INTO records (" +
                "date, value, counterID) VALUES" +
                $"('{r.date}', '{r.value}','{counterID}');";

            ExecuteQuery(s);
        }

        //Метод вытаскивает все данные по арендаторам из таблицы clients из БД и возвращает заполненный объект List<Client>
        public List<Client> selectClientsTable()
        {

            string s = "SELECT * FROM clients;";

            using (SqliteConnection connection = getConnection())
            {
                connection.Open();

                SqliteCommand cmd = connection.CreateCommand();
                cmd.CommandText = s;

                List<Client> list = new List<Client>();
                using (SqliteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Client c = new Client();
                        c.ID = reader.GetInt32(0);
                        c.name = reader.GetString(1);
                        c.roomsClient.AddRange(selectRoomsTable(c.ID));
                        list.Add(c);
                    }
                }
                return list;
            }
        }

        public int selectCurrentID()//string nameTable
        {

            Int32 result = -1;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string sql = "SELECT last_insert_rowid()";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                int lastID = (Int32)cmd.ExecuteScalar();
            }
            return result;
        }
        //Метод вытаскивает данные по арендатору из таблицы rooms из БД и возвращает заполненный объект List<Room>
        public List<Room> selectRoomsTable(int clientID)
        {

            string s = "SELECT * FROM rooms WHERE clientID="+ clientID .ToString()+ ";";

            using (SqliteConnection connection = getConnection())
            {
                connection.Open();

                SqliteCommand cmd = connection.CreateCommand();
                cmd.CommandText = s;

                List<Room> list = new List<Room>();
                using (SqliteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Room r = new Room();
                        r.ID = reader.GetInt32(0);
                        r.building = reader.GetString(1);
                        r.room = reader.GetString(2);
                        r.counters = selectCountersTable(r.ID);
                        list.Add(r);
                    }
                }
                return list;
            }
        }

        public int selectRoomID(string building, string room)
        {

            string s = "SELECT DISTINCT ID FROM rooms WHERE building=\'" + building + "\' AND room=\'"+room+"\';";
            int ID = 0;
            using (SqliteConnection connection = getConnection())
            {
                connection.Open();

                SqliteCommand cmd = connection.CreateCommand();
                cmd.CommandText = s;
                using (SqliteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ID = reader.GetInt32(0);
                    }
                }
                return ID;
            }
        }
        //Метод вытаскивает данные по комнате из таблицы counters из БД и возвращает заполненный объект List<Counter>
        public List<Counter> selectCountersTable(int roomID)
        {

            string s = "SELECT * FROM counters WHERE roomID ="+ roomID.ToString() + ";";

            using (SqliteConnection connection = getConnection())
            {
                connection.Open();

                SqliteCommand cmd = connection.CreateCommand();
                cmd.CommandText = s;

                List<Counter> list = new List<Counter>();
                using (SqliteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Counter c = new Counter();
                        c.ID = reader.GetInt32(0);
                        c.number = reader.GetString(1);
                        c.ratio = reader.GetDouble(2);
                        c.records.AddRange(selectRecordsTable(c.ID));
                        list.Add(c);
                    }
                }
                return list;
            }
        }
        public int selectCounterID(string building, string room)
        {

            string s = "SELECT DISTINCT ID FROM rooms WHERE building=\'" + building + "\' AND room=\'" + room + "\';";
            int ID = 0;
            using (SqliteConnection connection = getConnection())
            {
                connection.Open();

                SqliteCommand cmd = connection.CreateCommand();
                cmd.CommandText = s;
                using (SqliteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ID = reader.GetInt32(0);
                    }
                }
                return ID;
            }
        }
        //Метод вытаскивает данные по счетчику из таблицы records из БД и возвращает заполненный объект List<Records>
        public List<Record> selectRecordsTable(int counterID)
        {

            string s = "SELECT * FROM records WHERE counterID =" + counterID.ToString() + ";";

            using (SqliteConnection connection = getConnection())
            {
                connection.Open();

                SqliteCommand cmd = connection.CreateCommand();
                cmd.CommandText = s;

                List<Record> list = new List<Record>();
                using (SqliteDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Record r = new Record();
                        r.ID = reader.GetInt32(0);
                        r.date = reader.GetDateTime(1);
                        r.value = reader.GetDouble(2);
                        list.Add(r);
                    }
                }
                return list;
            }
        }

    }
}
